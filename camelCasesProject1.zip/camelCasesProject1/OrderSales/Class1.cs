﻿using System;

namespace OrderSales
{
    public class Class1

}
}
