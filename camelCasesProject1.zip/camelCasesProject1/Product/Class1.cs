﻿using System;

namespace Product
{
    public class Class1
    {
    }
}
