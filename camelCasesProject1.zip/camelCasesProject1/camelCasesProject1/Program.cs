﻿using System;
using static System.Console;
using static System.Environment;
using static System.Convert;

namespace camelCasesProject1
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                bool quit = true;
                {
                    try
                    {
                        do
                        {
                            WriteLine($"Hello{NewLine}" +
                                //Main Menu
                                $"Please Choose an Option:{NewLine}" +
                                $"Enter 1 for: Add New Customer{NewLine}" +
                                $"Enter 2 for: Add New Product{NewLine}" +
                                $"Enter 3 for: Search for Customer{ NewLine}" +
                                $"Enter 4 for: Search for Product{NewLine}" +
                                $"Enter 5 for: View Sales{NewLine}" +
                                $"Enter 6 for: Quit");

                            int option = ToInt32(ReadLine());
                            WriteLine($"You entered option {option}");

                            //New Customer
                            if (option == 1)
                            {
                                WriteLine("You chose to add a new customer!");

                                //Input for New Customer
                                WriteLine("Enter Customer ID");
                                int customerID = ToInt32(ReadLine());
                                WriteLine("Enter Customer First Name");
                                string customerFirstName = ReadLine();
                                WriteLine("Enter Customer Last Name");
                                string customerLastName = ReadLine();
                                WriteLine("Enter Customer Email");
                                string customerEmail = ReadLine();
                                WriteLine("Enter Customer Street Address");
                                string customerAddress = ReadLine();
                                WriteLine("Enter Customer City, State Zip Code");
                                string customerCity = ReadLine();
                                WriteLine("Enter Customer Phone Number");
                                string customerPhone = ReadLine();

                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();

                                //Output New Customer
                                WriteLine($"Here's The New Customer You Added!{NewLine}" +
                                    $"Customer ID: {customerID}{NewLine}" +
                                    $"Customer Name: {customerFirstName}{customerLastName}{NewLine}" +
                                    $"Customer Email: {customerEmail}{NewLine}" +
                                    $"Customer Address: {customerAddress}{NewLine}" +
                                    $"Customer City, State Zipcode: {customerCity}{NewLine}" +
                                    $"Customer Phone: {customerPhone}");

                                //Back To Main Menu
                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();
                            }

                                //New Product
                                if (option == 2)
                                {
                                //Input For New Product
                                WriteLine("You Chose to Add a New Product!");

                                WriteLine("Enter Product ID");
                                int productID = ToInt32(ReadLine());
                                WriteLine("Enter Product Name");
                                string productName = ReadLine();
                                WriteLine("Enter Product Category");
                                string productCategory = ReadLine();
                                WriteLine("Enter Product Description");
                                string productDescription = ReadLine();
                                WriteLine("Enter Product Price");
                                decimal productPrice = ToDecimal(ReadLine());

                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();

                                //Output New Product
                                WriteLine($"Here's The New Product You Added!{NewLine}" +
                                    $"Product Price: {productID}{NewLine}" +
                                    $"Product Name: {productName}{NewLine}" +
                                    $"Product Category: {productCategory}{NewLine}" +
                                    $"Product Description: {productDescription}{NewLine}" +
                                    $"Product Price: ${productPrice}");

                                //Back To Main Menu
                                WriteLine("Enter Key to Continue!");
                                ReadLine();
                                }

                                //Search For Customer
                                if (option == 3)
                                {
                                WriteLine("You Chose to Search For A Customer!");

                                //ID or Name
                                WriteLine($"Please Choose an Option:{NewLine}" +
                                    $"Enter 1 For: Search By ID{NewLine}" +
                                    $"Enter 2 For: Search By Last Name");
                                int customerOption = ToInt32(ReadLine());
                                WriteLine($"You Entered Option {customerOption}");

                                //Search By ID
                                if (customerOption == 1)
                                {
                                    WriteLine("Enter Customer ID");
                                }

                                //Search By Name
                                if (customerOption == 2)
                                {
                                    WriteLine("Enter Customer Last Name");
                                }
                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();
                            }

                                //Search for Product
                                if (option == 4)
                                {
                                
                                    WriteLine("You Chose to Search For A Product!");

                                    //ID or Name
                                    WriteLine($"Please Choose an Option:{NewLine}" +
                                        $"Enter 1 For: Search By ID{NewLine}" +
                                        $"Enter 2 For: Search By Name");
                                    int productOption = ToInt32(ReadLine());
                                    WriteLine($"You Entered Option {productOption}");

                                    //Search By ID
                                    if (productOption == 1)
                                    {
                                        WriteLine("Enter Product ID");
                                    WriteLine("Enter Any Key to Continue!");
                                    ReadLine();
                                }

                                    //Search By Name
                                    if (productOption == 2)
                                    {
                                        WriteLine("Enter Product Name");
                                    WriteLine("Enter Any Key to Continue!");
                                    ReadLine();
                                }

                                }

                                //Calculate sales
                                if (option == 5)
                                {
                                    WriteLine("You Chose to View Sales");
                                WriteLine($"Please Choose an Option{NewLine}" +
                                    $"Enter 1 For: Sales By Product{NewLine}" +
                                    $"Enter 2 For: Sales by Customer Name");
                                int salesOption = ToInt32(ReadLine());

                                //Sales By Product
                                if (salesOption == 1)
                                {

                                    WriteLine($"To View Sales by Product Choose an Option{NewLine}" +
                                        $"Enter 1 For: Ascending{NewLine}" +
                                        $"Enter 2 For: Descending");
                                    int productSalesOption = ToInt32(ReadLine());
                                    
                                    //Ascending
                                    if (productSalesOption == 1)
                                    {
                                        WriteLine("Sales In Ascending Order");
                                        WriteLine("Enter Any Key to Continue!");
                                        ReadLine();
                                    }

                                    //Descending
                                    if (productSalesOption ==2)
                                    {
                                        WriteLine("Sales in Descending Order");
                                        WriteLine("Enter Any Key to Continue!");
                                        ReadLine();
                                    }
                                }
                                
                                //Sales By Customer
                                if (salesOption ==2)
                                {
                                    WriteLine($"To View Sales by Customer Choose an Option{NewLine}" +
                                        $"Enter 1 For: Ascending{NewLine}" +
                                        $"Enter 2 For: Descending");
                                    int customerSalesOption = ToInt32(ReadLine());

                                    //Ascending
                                    if (customerSalesOption == 1)
                                    {
                                        WriteLine("Sales In Ascending Order");
                                        WriteLine("Enter Any Key to Continue!");
                                        ReadLine();
                                    }

                                    //Descending
                                    if (customerSalesOption == 2)
                                    {
                                        WriteLine("Sales in Descending Order");
                                        WriteLine("Enter Any Key to Continue!");
                                        ReadLine();
                                    }
                                }

                                }
                                if (option == 6)
                                {
                                    WriteLine("Goodbye");
                                    quit = false;
                                }
                            }
                            while (quit) ;
                        }
                    catch (Exception)
                    {

                        throw;
                    }
                }
            }
        }
    }
}
