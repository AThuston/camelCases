﻿using System;
using static System.Console;
using static System.Environment;
using static System.Convert;
using System.Collections.Generic;
using CustomerInformationSystem;

namespace camelCasesProject1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> customers = new List<Customer>
            {
                new Customer {CustomerId=1, CustomerName="JoeDirt", CustomerLastName="Dirt", CustomerEmail="JoeDirt@Gmail.com", CustomerPhone="316-123-4567", CustomerAddress="1015 N Broadway", CustomerCity="Wichititty, KS 67203"},
                new Customer { CustomerId=2, CustomerName="John Doe", CustomerLastName="Doe",CustomerEmail="johndoe@wichita.edu", CustomerPhone="316-123-1234", CustomerAddress="1702 Fairmount"},
                new Customer { CustomerId=3, CustomerName="Adam Crabtree", CustomerLastName="Crabtree",CustomerEmail="adamcrabtree@wichita.edu", CustomerPhone="316-123-5678", CustomerAddress="1822 Fairmount"},
                new Customer { CustomerId=4, CustomerName="Mary Jane", CustomerLastName="Jane",CustomerEmail="maryjane@wichita.edu", CustomerPhone="316-123-9090", CustomerAddress="1413 Mulberry Drive"}
            };
            List<Product> products = new List<Product>
            {
                new Product { ProductId=201, ProductName="ProductX", ProductCategory="Category1", ProductDescription="Product X dummy description", ProductPrice=19.99m},
                new Product { ProductId=202, ProductName="ProductY", ProductCategory="Category2", ProductDescription="Product Y dummy description", ProductPrice=25.99m},
            };
            List<Sale> sales = new List<Sale>
            {
                new Sale { CustomerId=1, ProductId=201, PurchasePrice=19.99m},
                new Sale { CustomerId=1, ProductId=202, PurchasePrice=25.99m},
                new Sale { CustomerId=2, ProductId=201, PurchasePrice=19.99m},
                new Sale { CustomerId=2, ProductId=202, PurchasePrice=25.99m},
                new Sale { CustomerId=3, ProductId=201, PurchasePrice=19.99m}
            };
            bool quit = true;
                {
                    try
                    {
                        do
                        {
                            WriteLine($"Hello{NewLine}" +
                                //Main Menu
                                $"Please Choose an Option:{NewLine}" +
                                $"Enter 1 for: Add New Customer{NewLine}" +
                                $"Enter 2 for: Add New Product{NewLine}" +
                                $"Enter 3 for: Search for Customer{ NewLine}" +
                                $"Enter 4 for: Search for Product{NewLine}" +
                                $"Enter 5 for: View Sales{NewLine}" +
                                $"Enter 6 for: Quit");

                            int option = ToInt32(ReadLine());
                            WriteLine($"You entered option {option}");

                            //New Customer
                            if (option == 1)
                            {
                                WriteLine("You chose to add a new customer!");

                                //Input for New Customer
                                WriteLine("Enter Customer ID");
                                int customerID = ToInt32(ReadLine());
                                WriteLine("Enter Customer First Name");
                                string customerFirstName = ReadLine();
                                WriteLine("Enter Customer Last Name");
                                string customerLastName = ReadLine();
                                WriteLine("Enter Customer Email");
                                string customerEmail = ReadLine();
                                WriteLine("Enter Customer Street Address");
                                string customerAddress = ReadLine();
                                WriteLine("Enter Customer City, State Zip Code");
                                string customerCity = ReadLine();
                                WriteLine("Enter Customer Phone Number");
                                string customerPhone = ReadLine();

                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();

                                //Output New Customer
                                WriteLine($"Here's The New Customer You Added!{NewLine}" +
                                    $"Customer ID: {customerID}{NewLine}" +
                                    $"Customer Name: {customerFirstName}{customerLastName}{NewLine}" +
                                    $"Customer Email: {customerEmail}{NewLine}" +
                                    $"Customer Address: {customerAddress}{NewLine}" +
                                    $"Customer City, State Zipcode: {customerCity}{NewLine}" +
                                    $"Customer Phone: {customerPhone}");

                                //Back To Main Menu
                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();
                            }

                                //New Product
                                if (option == 2)
                                {
                                //Input For New Product
                                WriteLine("You Chose to Add a New Product!");

                                WriteLine("Enter Product ID");
                                int productID = ToInt32(ReadLine());
                                WriteLine("Enter Product Name");
                                string productName = ReadLine();
                                WriteLine("Enter Product Category");
                                string productCategory = ReadLine();
                                WriteLine("Enter Product Description");
                                string productDescription = ReadLine();
                                WriteLine("Enter Product Price");
                                decimal productPrice = ToDecimal(ReadLine());

                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();

                                //Output New Product
                                WriteLine($"Here's The New Product You Added!{NewLine}" +
                                    $"Product Price: {productID}{NewLine}" +
                                    $"Product Name: {productName}{NewLine}" +
                                    $"Product Category: {productCategory}{NewLine}" +
                                    $"Product Description: {productDescription}{NewLine}" +
                                    $"Product Price: ${productPrice}");

                                //Back To Main Menu
                                WriteLine("Enter Key to Continue!");
                                ReadLine();
                                }

                                //Search For Customer
                                if (option == 3)
                                {
                                WriteLine("You Chose to Search For A Customer!");

                                //ID or Name
                                WriteLine($"Please Choose an Option:{NewLine}" +
                                    $"Enter 1 For: Search By ID{NewLine}" +
                                    $"Enter 2 For: Search By Last Name");
                                int customerOption = ToInt32(ReadLine());
                                WriteLine($"You Entered Option {customerOption}");

                                //Search By ID
                                if (customerOption == 1)
                                {
                                    WriteLine("Enter Customer ID");
                                Customer c = new Customer();
                                string customerName;
                                int customerId = ToInt32(ReadLine());

                                customerName = c.GetCustomer(customers, customerId);
                                WriteLine("CustomerName: {0}", customerName);
                                }

                                //Search By Name
                                if (customerOption == 2)
                                {
                                    WriteLine("Enter Customer Last Name");
                                Customer c = new Customer();
                                int customerId;
                                string customerLastName = ReadLine();

                                customerId = c.GetCustomer(customers, customerLastName);
                                WriteLine("CustomerId: {0}", customerId);
                            }
                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();
                            }

                                //Search for Product
                                if (option == 4)
                                {
                                
                                    WriteLine("You Chose to Search For A Product!");

                                    //ID or Name
                                    WriteLine($"Please Choose an Option:{NewLine}" +
                                        $"Enter 1 For: Search By ID{NewLine}" +
                                        $"Enter 2 For: Search By Name");
                                    int productOption = ToInt32(ReadLine());
                                    WriteLine($"You Entered Option {productOption}");

                                    //Search By ID
                                    if (productOption == 1)
                                    {
                                        WriteLine("Enter Product ID");
                                Product p = new Product();
                                string productName;
                                int productId = ToInt32(ReadLine());

                                productName = p.GetProduct(products, productId);
                                WriteLine("ProductName: {0}", productName);
                                WriteLine("Enter Any Key to Continue!");
                                    ReadLine();
                                }

                                    //Search By Name
                                    if (productOption == 2)
                                    {
                                        WriteLine("Enter Product Name");
                                Product p = new Product();
                                int productId;
                                string productName = ReadLine();

                                productId = p.GetProduct(products, productName);
                                WriteLine("ProductId: {0}", productId);
                                WriteLine("Enter Any Key to Continue!");
                                    ReadLine();
                                }

                                }

                                //Calculate sales
                                if (option == 5)
                                {
                                    WriteLine("You Chose to View Sales");
                                WriteLine($"Please Choose an Option{NewLine}" +
                                    $"Enter 1 For: Sales By Product{NewLine}" +
                                    $"Enter 2 For: Sales by Customer Name");
                                int salesOption = ToInt32(ReadLine());

                                //Sales By Product
                                if (salesOption == 1)
                                {
                                WriteLine("Enter Product ID");
                                 Sale s = new Sale();
                                decimal totalSale = 0.0m;
                                int productId = ToInt32(ReadLine());

                                totalSale = s.TotalSalesByProduct(sales, productId);
                                WriteLine("Total Sales for productId:{0} is {1}", productId, totalSale);
                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();
                            }

                            //Sales By Customer
                            if (salesOption ==2)
                                {
                                WriteLine("Enter Customer ID");
                                Sale s = new Sale();
                                decimal totalSale = 0.0m;
                                int customerId = ToInt32(ReadLine());

                                totalSale = s.TotalSalesByCustomer(sales, customerId);
                                WriteLine("Total Sales for productId:{0} is {1}", customerId, totalSale);
                                WriteLine("Enter Any Key to Continue!");
                                ReadLine();
                            }

                                }
                                if (option == 6)
                                {
                                    WriteLine("Goodbye");
                                    quit = false;
                                }
                            }
                            while (quit) ;
                        }
                    catch (Exception)
                    {

                        throw;
                    }
                }
            }
        }
    }

